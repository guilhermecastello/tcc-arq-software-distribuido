package br.com.castello.scitsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScitSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
